/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progra9.pkg2;

import java.util.Scanner;



public class Progra92 {
    public static void depositar(float monto){
        if (monto > 0){
            
        }
    }


    
    public static cuentabanco cuentabanco= new cuentabanco();
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("==== Bienvenido al programa ====");
        System.out.println(""); 
        System.out.println("Ingrese su nombre: ");
        String cliente = entrada.next();
        System.out.println("Ingrese su número de cuenta: ");
        int numerodecuenta = entrada.nextInt();
        System.out.println("Ingrese su número telefonico: ");
        String telefono = entrada.next();
        
        System.out.println("Qué desea realizar?/n"
                + "1. Depositar/n"
                + "2. Retirar");
        int opcion = entrada.nextInt();
        switch(opcion){
            case 1:
                System.out.println("Ingrese el monto a depositar: ");
                float deposito = entrada.nextFloat();
                depositar(deposito);
                break;
            case 2:
                System.out.println("Ingrese el monto a retirar: ");
                float retiro = entrada.nextFloat();
                retirar(retiro);
                break;
            default:
                System.out.println("Opción no valida. Intente de nuevo.");
        }

        
        
    }
    
}
